# Specline · Short Talk

Presentation for Specline, a tool that helps engineers stay aware of an AI agent's drift from the spec while it carries out a task.

Diya Franklin · GD 503 Studio, Fall 2026

**Controls:** → / Enter / Space for the next slide, ← to go back.

Prototype: https://diya-f.github.io/Specline/
